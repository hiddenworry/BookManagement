/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookmanagement;

import data.Shelf;
import java.util.Scanner;

/**
 *
 * @author Nguyen Quoc Bao Se151333
 */
public class BookManagement {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("What do you want?");
        System.out.println("Enter 1 to add new book");
        System.out.println("Enter 2 to print a list of books in ascending price order");
        System.out.println("Enter 3 to show information of list book");
        System.out.println("Enter other to exit");
        Scanner sc =new Scanner(System.in);
        int input = 0;
        Shelf shelf = new Shelf();
        do {  System.out.println("------------------------------------------------------------------------------------------------------------------------");
            System.out.println("Your chosse: ");  
            try {
                 input = Integer.parseInt(sc.nextLine());
            if( input == 1 )
                shelf.addNewBook();
            if( input == 2 )
                shelf.SortingByPrice();
            if ( input == 3 )
                shelf.ShowInfor();
            } catch (Exception e) {
                System.out.println("Please input an integer from 1 to 3"); 
                System.out.println("the program was terminated");
                break;
            }
           
            
        } while ( input == 1 || input == 2 || input == 3);
        System.out.println("Thank you!!!!!");
    }
    
}
