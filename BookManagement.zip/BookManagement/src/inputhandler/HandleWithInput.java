/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inputhandler;

import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class HandleWithInput {
    public static double getADouble( String inputMsg, String errorMsg ){
        double input;
        Scanner sc =new Scanner(System.in);
        while(true){
            try {
                System.out.println(inputMsg);
                input = Double.parseDouble(sc.nextLine());
                return input;             
            } catch (Exception e) {
                System.out.println(errorMsg);
            }
        }
    }
    public static String getAString( String inputMsg, String errorMsg ){
        String input;
        Scanner sc =new Scanner(System.in);
        while (true){
            System.out.println(inputMsg);
            input = sc.nextLine().trim();
            if ( input.length()==0 || input.isEmpty())
                System.out.println(errorMsg);
            else
                return input;
        }   
    }
     public static String getID( String inputMsg, String errorMsg, String fomat ){
         Scanner sc =new Scanner(System.in);
         String id;
         boolean match;
         while(true){
             System.out.println(inputMsg);
             id = sc.nextLine();
             match = id.matches(fomat);
             if (id.isEmpty() || id.length()==0 || match==false)
                 System.out.println(errorMsg);
             else
                 return id;                           
         }                         
     }
    
}
