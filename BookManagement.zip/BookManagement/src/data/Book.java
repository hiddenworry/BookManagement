/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

/**
 *
 * @author Nguyen Quoc Bao Se151333
 */
public class Book {
    private String name;
    private String Id;
    private double price;

    public Book(String name, String Id, double price) {
        this.name = name;
        this.Id = Id;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Book{" + "name=" + name + ", Id=" + Id + ", price=" + price + '}';
    }
    
    public void showProfile(){
        System.out.printf(String.format("| %8s|%8s|%.4f |", Id, name, price));
    
    
    
    
    }

   

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
    
    
}
