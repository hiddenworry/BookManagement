/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;
import data.Book;
import inputhandler.HandleWithInput;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

/**
 *
 * @author Nguyen Quoc Bao Se151333
 */
public class Shelf {
    private ArrayList<Book> BookList= new ArrayList();
    private Scanner sc = new Scanner(System.in);
    
    public void addNewBook(){
        String name, Id;
        int pos;
        double price;
        System.out.println("------------------------------------------------------------------------------------");
        do {          
            Id = HandleWithInput.getID("Input ID of the book(fomat: [character]XXXX when X is digits):", "Please enter the correct format", "^[a-z]+\\d{4}$");
            pos = searchBookByID(Id);
            if(pos != -1)
                System.out.println("This boos is already exits, please input another!!!");    
        } while (pos != -1);
        name = HandleWithInput.getAString("Input name of the book: ", "something went wrong, please input again!!!");
        price = HandleWithInput.getADouble("Input price of the book: ", "something went wrong, please input again!!!");
        BookList.add(new Book(name, Id, price));
        System.out.println("Add book successfully");
    }
    public int searchBookByID(String ID){
        if (ID.isEmpty())
            return -1;
        for (int i = 0; i < BookList.size(); i++) {
            if ( BookList.get(i).getId().equalsIgnoreCase(ID) )
                return i;          
        }          
        return -1;   
    }
    public void SortingByPrice(){
       if(BookList.isEmpty())
            System.out.println("Sorry, we couldn't find any book on the data");
       else {
        Comparator CompareByPrice = new Comparator<Book>() {
            @Override
            public int compare(Book o1, Book o2) {
                return Double.compare(o1.getPrice(), o2.getPrice());
                          }      };
      Collections.sort(BookList, CompareByPrice);
        System.out.println("--------------------------------------------------------------------------------------");
      String header = String.format("|%8s|%8s|%8s|","ID", "Name", "Price");
        System.out.println(header);
        for (int i = 0; i < BookList.size(); i++) {
            BookList.get(i).showProfile();
            System.out.println("");
        }
      }    
    }
    public void ShowInfor(){
        if (BookList.isEmpty())
            System.out.println("Sorry, we couldn't find any book on the data");
        else{
        System.out.println("------------------------------------------------------------------------------------");
        System.out.println(this.BookList.toString());
        System.out.println("");}
    
    
    }
    
    
    
}
